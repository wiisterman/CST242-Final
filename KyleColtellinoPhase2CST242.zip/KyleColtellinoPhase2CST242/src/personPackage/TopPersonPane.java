package personPackage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class TopPersonPane 
{
	GridPane topPersonPane;

	private Label personLbl;
	private Label personFirstNameLbl;
	private Label personLastNameLbl;
	private Label phoneNumberLbl;
	private Label personIDLbl;
	private AddressPane addressPane;
	private TextField personFirstNameField;
	private TextField personLastNameField;
	private TextField phoneNumberField;
	private TextField personIDField;
	private TextField idSearchField;
	
	public TopPersonPane()
	{
		topPersonPane = new GridPane();
		addressPane = new AddressPane();
		topPersonPane.setPadding(new Insets(10, 10, 10, 10));
		topPersonPane.setVgap(10);
		topPersonPane.setHgap(10);
		topPersonPane.setAlignment(Pos.CENTER);

		topPersonPane.setStyle("-fx-background-color:#4286f4");
		personLbl = new Label("Person");
		personFirstNameLbl = new Label("First Name");
		personLastNameLbl = new Label("Last Name");
		phoneNumberLbl = new Label("Phone Number");
		personIDLbl = new Label("ID");

		
		personFirstNameField = new TextField();
		personLastNameField = new TextField();
		phoneNumberField = new TextField();
		personIDField = new TextField();
		idSearchField = new TextField();
		personIDField.setEditable(false);

		phoneNumberField.setPromptText("###-###-####");
		// Putting everything on Person Pane
		topPersonPane.add(personLbl, 0, 0);
		personLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		// R1
		topPersonPane.add(personFirstNameLbl, 0, 1);
		topPersonPane.add(personFirstNameField, 1, 1);
		// R2
		topPersonPane.add(personLastNameLbl, 0, 2);
		topPersonPane.add(personLastNameField, 1, 2);
		// R3
		topPersonPane.add(phoneNumberLbl, 0, 3);
		topPersonPane.add(phoneNumberField, 1, 3);
		// R4
		topPersonPane.add(personIDLbl, 0, 4);
		topPersonPane.add(personIDField, 1, 4);
		// R5
//		idSearchField.setPromptText("Search ID");
//		topPersonPane.add(idSearchField, 1, 5);
		topPersonPane.add(addressPane.getAddressPane(), 2, 0, 3, 7);
		
	}
	public TextField getPersonFirstNameField() {
		return personFirstNameField;
	}

	public void setPersonFirstNameField(String string) {
		this.personFirstNameField.setText(string);
	}

	public TextField getPersonLastNameField() {
		return personLastNameField;
	}

	public void setPersonLastNameField(String string) {
		this.personLastNameField.setText(string);
	}

	public TextField getPhoneNumberField() {
		return phoneNumberField;
	}

	public void setPhoneNumberField(String string) {
		this.phoneNumberField.setText(string);
	}

	public TextField getPersonIDField() {
		return personIDField;
	}

	public void setPersonIDField(String string) {
		this.personIDField.setText(string);
	}
	
	public TextField getIdSearchField() {
		return idSearchField;
	}
	public GridPane getTopPersonPane() {
		return topPersonPane;
	}
	public void setTopPersonPane(GridPane topPersonPane) {
		this.topPersonPane = topPersonPane;
	}
	public AddressPane getAddressPane() {
		return addressPane;
	}
	public void setAddressPane(AddressPane addressPane) {
		this.addressPane = addressPane;
	}

}
