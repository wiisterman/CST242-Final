package personPackage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;

public class PersonPane {
	private TopPersonPane topPersonPane;
	private MiddleStudentPane middleStudentPane;
	private MiddleFacultyPane middleFacultyPane;
	private BottomButtonPane bottomButtonPane;
	private GridPane personPane;

	public PersonPane() {
		topPersonPane = new TopPersonPane();
		middleStudentPane = new MiddleStudentPane();
		middleFacultyPane = new MiddleFacultyPane();
		bottomButtonPane = new BottomButtonPane();
		personPane = new GridPane();

		personPane.setAlignment(Pos.CENTER);
		personPane.setPadding(new Insets(20));
		personPane.add(topPersonPane.getTopPersonPane(), 0, 0);
		personPane.add(middleStudentPane.getMiddleStudentPane(), 0, 1);
		personPane.add(bottomButtonPane.getBottomButtonPane(), 0, 2);

	}

	public TopPersonPane getTopPersonPane() {
		return topPersonPane;
	}

	public MiddleStudentPane getMiddleStudentPane() {
		return middleStudentPane;
	}

	public MiddleFacultyPane getMiddleFacultyPane() {
		return middleFacultyPane;
	}

	public BottomButtonPane getBottomButtonPane() {
		return bottomButtonPane;
	}

	public GridPane getPersonPane() {
		return personPane;
	}

}
