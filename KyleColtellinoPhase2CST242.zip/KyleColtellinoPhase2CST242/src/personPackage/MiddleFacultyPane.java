package personPackage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class MiddleFacultyPane 
{
private GridPane middleFacultyPane;
	private Label facultyLbl;
	private Label rankLbl;
	private TextField rankField;
	private Label salaryLbl;
	private TextField salaryField;
	private Label coursesTeachingLbl;
	private TextField coursesTeachingField;
	
	public MiddleFacultyPane()
	{
		middleFacultyPane = new GridPane();
		middleFacultyPane.setPadding(new Insets(10, 10, 10, 10));
		middleFacultyPane.setVgap(8);
		middleFacultyPane.setHgap(8);
		facultyLbl = new Label("Faculty");
		facultyLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		rankLbl = new Label("Rank");
		rankField = new TextField();
		salaryLbl = new Label("Salary");
		salaryField = new TextField();
		coursesTeachingLbl = new Label("Courses Teaching");
		coursesTeachingField = new TextField();

		middleFacultyPane.add(facultyLbl, 0, 0);

		// R1
		middleFacultyPane.add(rankLbl, 0, 1);
		middleFacultyPane.add(rankField, 1, 1);
		// R2
		middleFacultyPane.add(salaryLbl, 0, 2);
		middleFacultyPane.add(salaryField, 1, 2);
		// R3
		middleFacultyPane.add(coursesTeachingLbl, 0, 3);
		middleFacultyPane.add(coursesTeachingField, 1, 3);
		//
		middleFacultyPane.setAlignment(Pos.CENTER);
	}
	public TextField getRankField() {
		return rankField;
	}

	public void setRankField(String string) {
		this.rankField.setText(string);
	}

	public TextField getSalaryField() {
		return salaryField;
	}

	public void setSalaryField(String salaryField) {
		this.salaryField.setText(salaryField);
	}

	public TextField getCoursesTeachingField() {
		return coursesTeachingField;
	}

	public void setCoursesTeachingField(String coursesTeachingField) {
		this.coursesTeachingField.setText(coursesTeachingField);
	}
	public GridPane getMiddleFacultyPane() {
		return middleFacultyPane;
	}
	public void setMiddleFacultyPane(GridPane middleFacultyPane) {
		this.middleFacultyPane = middleFacultyPane;
	}
	

}
