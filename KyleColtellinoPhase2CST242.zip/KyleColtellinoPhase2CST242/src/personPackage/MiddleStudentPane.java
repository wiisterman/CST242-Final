package personPackage;

import java.util.ArrayList;
import java.util.Arrays;

import coursePackage.Course;
import coursePackage.MasterCourseBag;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class MiddleStudentPane 
{
	private GridPane middleStudentPane;
	private Label studentLbl;
	private Label coursesTookLbl;
	private ListView<String> coursesTookLV;
	private Label coursesTakingLbl;
	private ListView<String> coursesTakingLV;
	private Label coursesNeededLbl;
	private TextArea coursesNeededArea;
	private Label majorLbl;
	private ListView<String> majorLV;
	private Label creditsTakingLbl;
	private TextField creditsTakingField;
	private Label gpaLbl;
	private TextField gpaField;
	private MasterCourseBag courseBag;
	private ArrayList<Course> testCourse;
	
	public MiddleStudentPane()
	{
		middleStudentPane = new GridPane();
		middleStudentPane.setVgap(10);
		middleStudentPane.setHgap(10);
		middleStudentPane.setPadding(new Insets(10, 10, 10, 10));
		courseBag = new MasterCourseBag();
		courseBag.load();
		
		studentLbl = new Label("Student");
		studentLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		coursesTookLbl = new Label("Courses Took");
		coursesTookLV = new ListView<String>();
		coursesTakingLbl = new Label("Courses Taking");
		coursesTakingLV = new ListView<String>();
		coursesNeededLbl = new Label("Courses Needed");
		coursesNeededArea = new TextArea();
		majorLbl = new Label("Major");
		majorLV = new ListView<String>();
		creditsTakingLbl = new Label("Credits Taking");
		creditsTakingField = new TextField();
		gpaLbl = new Label("GPA");
		gpaField = new TextField();

		coursesTookLV.getSelectionModel().getSelectedItems();
		coursesTakingLV.getSelectionModel().getSelectedItems();
		String courseString = courseBag.getCourseCRN();
		
		String[] c = courseString.split(",");
		ArrayList<String> courseList = new ArrayList<>(Arrays.asList(c));
		ObservableList<String> items = FXCollections.observableArrayList(courseList);
		coursesTookLV.setItems(items);
		coursesTakingLV.setItems(items);
		
		majorLV.getSelectionModel().getSelectedItems();
		String majorString = "CST-Computer Information,CSE-Computer Science,AST-Astronomy,CHE-Chemistry,"
				+ "BIO-Biology,SPN-Spanish";

		String[] m = majorString.split(",");
		ArrayList<String> majorList = new ArrayList<>(Arrays.asList(m));
		ObservableList<String> mList = FXCollections.observableArrayList(majorList);
		majorLV.setItems(mList);
		
		// Populate the msp

		// R0
		middleStudentPane.add(studentLbl, 0, 0);

		// R1
		coursesTookLV.setPrefHeight(50);
		middleStudentPane.add(coursesTookLbl, 0, 1);
		middleStudentPane.add(coursesTookLV, 1, 1);

		// R2
		coursesTakingLV.setPrefHeight(50);
		middleStudentPane.add(coursesTakingLbl, 0, 2);
		middleStudentPane.add(coursesTakingLV, 1, 2);

		// R3
		coursesNeededArea.setPrefHeight(50);
		middleStudentPane.add(coursesNeededLbl, 0, 3);
		middleStudentPane.add(coursesNeededArea, 1, 3);

		// R4
		majorLV.setPrefHeight(50);
		middleStudentPane.add(majorLbl, 0, 4);
		middleStudentPane.add(majorLV, 1, 4);

		// R5
		middleStudentPane.add(creditsTakingLbl, 0, 5);
		middleStudentPane.add(creditsTakingField, 1, 5);

		// R6
		middleStudentPane.add(gpaLbl, 0, 6);
		middleStudentPane.add(gpaField, 1, 6);

		middleStudentPane.setAlignment(Pos.CENTER);
	}
	public void loadArray()
	{
		courseBag.load();
	}
	public TextArea getCoursesNeededArea() {
		return coursesNeededArea;
	}

	public void setCoursesNeededArea(String string) {
		this.coursesNeededArea.setText(string);
		;
	}

	public TextField getCreditsTakingField() {
		return creditsTakingField;
	}

	public void setCreditsTakingField(String creditsTakingField) {
		this.creditsTakingField.setText(creditsTakingField);
		
	}

	public TextField getGpaField() {
		return gpaField;
	}

	public void setGpaField(String gpaField) {
		this.gpaField.setText(gpaField);
	}

	public Label getCoursesTookLbl() {
		return coursesTookLbl;
	}

	public ListView<String> getCoursesTookLV() {
		return coursesTookLV;
	}

	public ListView<String> getCoursesTakingLV() {
		return coursesTakingLV;
	}

	public void setCoursesTookLbl(Label coursesTookLbl) {
		this.coursesTookLbl = coursesTookLbl;
	}

	public void setCoursesTookLV(ListView<String> coursesTookLV) {
		this.coursesTookLV = coursesTookLV;
	}

	public void setCoursesTakingLV(ListView<String> coursesTakingLV) {
		this.coursesTakingLV = coursesTakingLV;
	}

	public ListView<String> getMajorLV() {
		return majorLV;
	}

	public void setMajorLV(ListView<String> majorLV) {
		this.majorLV = majorLV;
	}
	public GridPane getMiddleStudentPane() {
		return middleStudentPane;
	}
	public void setMiddleStudentPane(GridPane middleStudentPane) {
		this.middleStudentPane = middleStudentPane;
	}
	
	public void setListViews(MasterCourseBag courseBag)
	{
		coursesTookLV.getSelectionModel().getSelectedItems();
		coursesTakingLV.getSelectionModel().getSelectedItems();
		String courseString = courseBag.getCourseCRN();
		
		String[] c = courseString.split(",");
		ArrayList<String> courseList = new ArrayList<>(Arrays.asList(c));
		ObservableList<String> items = FXCollections.observableArrayList(courseList);
		coursesTookLV.setItems(items);
		coursesTakingLV.setItems(items);
		
	}
	
	
}
