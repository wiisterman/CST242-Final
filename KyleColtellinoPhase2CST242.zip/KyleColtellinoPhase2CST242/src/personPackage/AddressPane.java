package personPackage;

import java.util.ArrayList;
import java.util.Arrays;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class AddressPane 
{
	GridPane addressPane = new GridPane();

	private Label addressLbl;
	private Label streetNumberLbl;
	private Label streetNameLbl;
	private Label cityLbl;
	private Label stateLbl;
	private TextField stateField;

	private Label zipCodeLbl;
	private ListView<String> stateView;
	private TextField streetNumberField;
	private TextField streetNameField;
	private TextField cityField;
	private TextField zipCodeField;
	
	public AddressPane()
	{
		addressPane = new GridPane();
		addressPane.setPadding(new Insets(10, 10, 10, 10));
		addressPane.setVgap(10);
		addressPane.setHgap(10);

		stateView =new ListView<String>();
		stateView.setPrefHeight(50);
		stateView.getSelectionModel().getSelectedItem();
		
		String states = "Alabama,Alaska,Arizona,Arkansas,California,"
				+ "Colorado,Connecticut,Delaware,Florida,Georgia,Hawaii,"
				+ "Idaho,Illinois,Indiana,Iowa,Kansas,Kentucky,Louisiana,"
				+ "Maine,Maryland,Massachusetts,Michigan,Minnesota,"
				+ "Mississippi,Missouri,Montana,Nebrask,Nevada,"
				+ "New Hampshire,New Jersey,New Mexico,New York,"
				+ "North Carolina,North Dakota,Ohio,Oklahoma,Oregon,"
				+ "Pennsylvania,Rhode Island,South Carolina,South Dakota,"
				+ "Tennessee,Texas,Utah,Vermont,Virginia,Washington,"
				+ "West Virginia,Wisconsin,Wyoming,District of Columbia,"
				+ "Puerto Rico,Guam,American Samoa,U.S.Virgin Islands,"
				+ "Northern Mariana Islands";

		String[] c = states.split(",");
		ArrayList<String> courseList = new ArrayList<>(Arrays.asList(c));
		ObservableList<String> items = FXCollections.observableArrayList(courseList);
		stateView.setItems(items);
		
		
		addressLbl = new Label("Address");
		streetNumberLbl = new Label("Street Number");
		streetNameLbl = new Label("Street Name");
		cityLbl = new Label("City");
		stateLbl = new Label("State");
		stateField = new TextField();
		
		zipCodeLbl = new Label("Zip Code");

		streetNumberField = new TextField();
		streetNameField = new TextField();
		cityField = new TextField();
		zipCodeField = new TextField();
		
		// R0
		addressLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		addressPane.add(addressLbl, 0, 0);
		// R1
		addressPane.add(streetNumberLbl, 0, 1);
		addressPane.add(streetNumberField, 1, 1);
		// R2
		addressPane.add(streetNameLbl, 0, 2);
		addressPane.add(streetNameField, 1, 2);
		// R3
		addressPane.add(cityLbl, 0, 3);
		addressPane.add(cityField, 1, 3);
		// R4
		stateField.setEditable(false);
		addressPane.add(stateLbl, 0, 4);
		addressPane.add(stateView, 1, 4);
		addressPane.add(stateField, 1, 5);
		
		// R5
		addressPane.add(zipCodeLbl, 0, 6);
		addressPane.add(zipCodeField, 1, 6);
		addressPane.setStyle("-fx-background-color:#f44242");
		
	}
	
	public TextField getStateField() {
		return stateField;
	}

	public void setStateField(String stateField) {
		this.stateField.setText(stateField);
	}

	public TextField getStreetNumberField() {
		return streetNumberField;
	}

	public void setStreetNumberField(String streetNumberField) {
		this.streetNumberField.setText(streetNumberField);
	}

	public TextField getStreetNameField() {
		return streetNameField;
	}

	public void setStreetNameField(String streetNameField) {
		this.streetNameField.setText(streetNameField);
	}

	public TextField getCityField() {
		return cityField;
	}

	public void setCityField(String cityField) {
		this.cityField.setText(cityField);
	}

	public TextField getZipCodeField() {
		return zipCodeField;
	}

	public void setZipCodeField(String zipCodeField) {
		this.zipCodeField.setText(zipCodeField);
	}

	public ListView<String> getStateView() {
		return stateView;
	}

	public void setStateView(ListView<String> listView) {
		this.stateView = listView;
	}

	public GridPane getAddressPane() {
		return addressPane;
	}

	public void setAddressPane(GridPane addressPane) {
		this.addressPane = addressPane;
	}
	
}
