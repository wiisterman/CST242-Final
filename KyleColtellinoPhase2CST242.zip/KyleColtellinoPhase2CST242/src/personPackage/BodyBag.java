package personPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class BodyBag  {

	ArrayList<Person> boddyBagArray = new ArrayList();

	public void add(Person s) {
		boddyBagArray.add(s);
	}
	// public void addF(Faculty f)
	// {
	// arr.add(new Faculty(f.getfName(),f.getlName(),f.getSalary()));
	// }

	public Person contains(String anItem) {
		String found = "Object Not Found!";

		for (int i = 0; (i < boddyBagArray.size()); i++) {
			if (anItem.equals(boddyBagArray.get(i).getId())) {
				return boddyBagArray.get(i);
			}
		}

		return null;
	}

	public Person removeByID(String id) {
		int i = 0;
		for (Person s : boddyBagArray) {
			if (s.getId().equals(id)) {
				break;
			}
			i++;
		}
		if (i < boddyBagArray.size()) {
			return boddyBagArray.remove(i);
		}
		return null;

	}

	public String display() {
		String test = "";
		for (int i = 0; i < boddyBagArray.size(); i++) {
			test += (boddyBagArray.get(i) + "\n");
		}

		return test;
	}

	public boolean isStudent(String id) {
		String nFound = "Object Not Found!";

		for (int i = 0; (i < boddyBagArray.size()); i++) {
			if (id.equals(boddyBagArray.get(i).getId())) {

				if (boddyBagArray.get(i) instanceof Student) {
					return true;
				}

			}
		}

		return false;
	}

	public boolean isFaculty(String id) {
		String nFound = "Object Not Found!";

		for (int i = 0; (i < boddyBagArray.size()); i++) {
			if (id.equals(boddyBagArray.get(i).getId())) {

				if (boddyBagArray.get(i) instanceof Faculty) {
					return true;
				}

			}
		}

		return false;
	}

	public void update(Person person) 
	{
	
		if(person instanceof Faculty)
		{
			for (int i = 0; (i < boddyBagArray.size()); i++) {
				if (person.getId().equals(boddyBagArray.get(i).getId())) {
					 boddyBagArray.set(i, person);
				}
			}
		}
		else if(person instanceof Student)
		{
			for (int i = 0; (i < boddyBagArray.size()); i++) {
				if (person.getId().equals(boddyBagArray.get(i).getId())) {
					 boddyBagArray.set(i, person);
				}
			}
		}
	
	}

	public void saveS() {
		FileOutputStream fos;
		for(int i = 0; i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i) instanceof Faculty)
			{
				boddyBagArray.remove(i);
			}
		}
		try {
			fos = new FileOutputStream("Data/Student.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(boddyBagArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	};

	public void loadS() {
		try {
			FileInputStream fis = new FileInputStream("Data/Student.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			boddyBagArray = (ArrayList<Person>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found: Student.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void saveF() {
		FileOutputStream fos;
		for(int i = 0; i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i) instanceof Student)
			{
				boddyBagArray.remove(i);
			}
		}
		try {
			fos = new FileOutputStream("Data/Faculty.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(boddyBagArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	};

	public void loadF() {
		try {
			FileInputStream fis = new FileInputStream("Data/Faculty.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			boddyBagArray = (ArrayList<Person>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found: Faculty.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void saveStudent(File file) {
		FileOutputStream fos;
		try {
						
			fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(boddyBagArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	};
	
	public void saveFaculty(File file) {
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(boddyBagArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	};
	
	public void importStudentFile(File file) {
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			boddyBagArray = (ArrayList<Person>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Can't Open File");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i = 0;i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i) instanceof Faculty)
			{
				boddyBagArray.remove(i);
			}
		}
	}
	
	public void importFacultyFile(File file) {
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			boddyBagArray = (ArrayList<Person>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Can't Open File");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i = 0;i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i) instanceof Student)
			{
				boddyBagArray.remove(i);
			}
		}
	}
	
	public String displayStudent()
	{
		String test = "";
		for(int i = 0;i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i)instanceof Student)
			{
				test += (boddyBagArray.get(i) + "\n");
			}
		}
		return test;
	}
	public String displayFaculty()
	{
		String test = "";
		for(int i = 0;i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i)instanceof Faculty)
			{
				test += (boddyBagArray.get(i) + "\n");
			}
		}
		return test;
	}
	
	public ArrayList<Faculty> getAllFaculty()
	{
		ArrayList<Faculty> facultyArray = new ArrayList<>();
		for(int i = 0;i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i)instanceof Faculty)
			{
				facultyArray.add((Faculty) boddyBagArray.get(i)) ;
			}
		}
		return facultyArray;
	}
	
	public ArrayList<Student> getAllStudent()
	{
		ArrayList<Student> StudentArray = new ArrayList<>();
		for(int i = 0;i<boddyBagArray.size();i++)
		{
			if(boddyBagArray.get(i)instanceof Student)
			{
				StudentArray.add((Student) boddyBagArray.get(i)) ;
			}
		}
		return StudentArray;
	}
}
