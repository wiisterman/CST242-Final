package personPackage;

import java.io.Serializable;
import java.util.ArrayList;

import coursePackage.Course;

public class Student  extends Person implements Serializable
{

	private ArrayList<Course> coursesTook;
	private ArrayList<Course> coursesTaking;
	private ArrayList<Course> coursesNeeded;
	private double gpa;
	private double creditsTaking;
	private String major;
	public Student(String firstName, String lastName, String phoneNumber, Address address,
			ArrayList<Course> coursesTook, ArrayList<Course> coursesTaking, ArrayList<Course> coursesNeeded, double gpa,
			double creditsTaking, String major) {
		super(firstName, lastName, phoneNumber, address);
		this.coursesTook = coursesTook;
		this.coursesTaking = coursesTaking;
		this.coursesNeeded = coursesNeeded;
		this.gpa = gpa;
		this.creditsTaking = creditsTaking;
		this.major = major;
	}
	public ArrayList<Course> getCoursesTook() {
		return coursesTook;
	}
	public void setCoursesTook(ArrayList<Course> coursesTook) {
		this.coursesTook = coursesTook;
	}
	public ArrayList<Course> getCoursesTaking() {
		return coursesTaking;
	}
	public void setCoursesTaking(ArrayList<Course> coursesTaking) {
		this.coursesTaking = coursesTaking;
	}
	public ArrayList<Course> getCoursesNeeded() {
		return coursesNeeded;
	}
	public void setCoursesNeeded(ArrayList<Course> coursesNeeded) {
		this.coursesNeeded = coursesNeeded;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	public double getCreditsTaking() {
		return creditsTaking;
	}
	public void setCreditsTaking(double creditsTaking) {
		this.creditsTaking = creditsTaking;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public double getCreditsByCoursesTaking(ArrayList<Course> coursesTaking)
	{
		//Make a loop to add all the course.getCredits when second stage
		return creditsTaking;
		
	}
	@Override
	public String toString() {
		return "\n---------\nStudent\n" + super.toString() + "Courses Took: \n" + coursesTook.toString() + "\nCourses Taking: \n"
				+ coursesTaking.toString() + "\nCourses Needed:\n " + coursesNeeded.toString() +"\nCredits Taking: "+ creditsTaking +"\nGPA: " + gpa  + "\nMajor: " + major+"\n---------\n";
	}
	
	
}
