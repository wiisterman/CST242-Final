package personPackage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class BottomButtonPane {
	private GridPane bottomButtonPane;

	private Button insertStudentBtn;
	private Button insertFacultyBtn;
	private Button removeBtn;
	private Button updateBtn;
	private Button searchBtn;
	private Button studentView;
	private Button facultyView;
	private Button displayStudentBtn;
	private Button displayFacultyBtn;
	private Button reInsertCoursesTakingBtn;
	
	private Button reInsertCoursesTookBtn;

	private Button saveBtn;

	public BottomButtonPane()
	{
		bottomButtonPane = new GridPane();
		bottomButtonPane.setHgap(8);
		bottomButtonPane.setVgap(8);
		bottomButtonPane.setPadding(new Insets(5, 5, 5, 5));

	
		reInsertCoursesTakingBtn = new Button("Clear Courses Taking");
		reInsertCoursesTookBtn = new Button("Clear Courses Took");
		insertStudentBtn = new Button("Insert Student");
		insertFacultyBtn = new Button("Insert Faculty");
		removeBtn = new Button("Remove");
		updateBtn = new Button("Update");
		searchBtn = new Button("Search");
		displayStudentBtn = new Button("Display");
		displayFacultyBtn = new Button("Display");
		saveBtn = new Button("Save");
		facultyView = new Button("Show Faculty");
		studentView  = new Button("Show Student");
		
		bottomButtonPane.setAlignment(Pos.CENTER);

		bottomButtonPane.add(studentView, 0, 0);
		bottomButtonPane.add(insertStudentBtn, 1, 0);
		bottomButtonPane.add(removeBtn, 2, 0);
		bottomButtonPane.add(updateBtn, 3, 0);
		bottomButtonPane.add(searchBtn, 4, 0);
		bottomButtonPane.add(saveBtn, 5, 0);
		bottomButtonPane.add(displayStudentBtn, 6, 0);
		bottomButtonPane.add(displayFacultyBtn, 7, 0);
		bottomButtonPane.add(insertFacultyBtn, 8, 0);
		bottomButtonPane.add(facultyView, 9, 0);
		
		reInsertCoursesTakingBtn.setPrefWidth(150);
		reInsertCoursesTookBtn.setPrefWidth(150);
		insertStudentBtn.setPrefWidth(100);
		removeBtn.setPrefWidth(100);
		updateBtn.setPrefWidth(100);
		searchBtn.setPrefWidth(100);
		insertFacultyBtn.setPrefWidth(100);
		displayStudentBtn.setPrefWidth(100);
		displayFacultyBtn.setPrefWidth(100);
		saveBtn.setPrefWidth(100);
		facultyView.setPrefWidth(100);
		studentView.setPrefWidth(100);
		
	}

	public GridPane getBottomButtonPane() {
		return bottomButtonPane;
	}

	public Button getInsertStudentBtn() {
		return insertStudentBtn;
	}

	public Button getInsertFacultyBtn() {
		return insertFacultyBtn;
	}

	public Button getRemoveBtn() {
		return removeBtn;
	}

	public Button getUpdateBtn() {
		return updateBtn;
	}

	public Button getSearchBtn() {
		return searchBtn;
	}

	public Button getStudentView() {
		return studentView;
	}

	public Button getFacultyView() {
		return facultyView;
	}

	public Button getSaveBtn() {
		return saveBtn;
	}

	public void setBottomButtonPane(GridPane bottomButtonPane) {
		this.bottomButtonPane = bottomButtonPane;
	}

	public void setInsertStudentBtn(Button insertStudentBtn) {
		this.insertStudentBtn = insertStudentBtn;
	}

	public void setInsertFacultyBtn(Button insertFacultyBtn) {
		this.insertFacultyBtn = insertFacultyBtn;
	}

	public void setRemoveBtn(Button removeBtn) {
		this.removeBtn = removeBtn;
	}

	public void setUpdateBtn(Button updateBtn) {
		this.updateBtn = updateBtn;
	}

	public void setSearchBtn(Button searchBtn) {
		this.searchBtn = searchBtn;
	}

	public void setStudentView(Button studentView) {
		this.studentView = studentView;
	}

	public void setFacultyView(Button facultyView) {
		this.facultyView = facultyView;
	}

	public void setSaveBtn(Button saveBtn) {
		this.saveBtn = saveBtn;
	}

	public Button getDisplayStudentBtn() {
		return displayStudentBtn;
	}

	public Button getDisplayFacultyBtn() {
		return displayFacultyBtn;
	}

	public void setDisplayStudentBtn(Button displayStudentBtn) {
		this.displayStudentBtn = displayStudentBtn;
	}

	public void setDisplayFacultyBtn(Button displayFacultyBtn) {
		this.displayFacultyBtn = displayFacultyBtn;
	}
	
	public Button getReInsertCoursesTookBtn() {
		return reInsertCoursesTookBtn;
	}

	public void setReInsertCoursesTakingBtn(Button reInsertCoursesTakingBtn) {
		this.reInsertCoursesTakingBtn = reInsertCoursesTakingBtn;
	}
	public Button getReInsertCoursesTakingBtn() {
		return reInsertCoursesTakingBtn;
	}


	public void setReInsertCoursesTookBtn(Button reInsertCoursesTookBtn) {
		this.reInsertCoursesTookBtn = reInsertCoursesTookBtn;
	}


}
