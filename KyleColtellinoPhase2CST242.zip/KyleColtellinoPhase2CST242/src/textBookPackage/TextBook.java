package textBookPackage;

import java.io.Serializable;
import java.util.ArrayList;

public class TextBook implements Serializable {

	private String bookISBN;
	private String bookTitle;
	private ArrayList<Author> bookAuthors;
	private double bookPrice;

	public TextBook(String bookISBN, String bookTitle, ArrayList<Author> author, double bookPrice) {
		super();
		this.bookISBN = bookISBN;
		this.bookTitle = bookTitle;
		this.bookAuthors = author;
		this.bookPrice = bookPrice;
	}

	public String getBookISBN() {
		return bookISBN;
	}

	public void setBookISBN(String bookISBN) {
		this.bookISBN = bookISBN;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public ArrayList<Author> getBookAuthors() {
		return bookAuthors;
	}

	public void setBookAuthors(ArrayList<Author> bookAuthors) {
		this.bookAuthors = bookAuthors;
	}

	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	@Override
	public String toString() {
		return "\n[TextBook]\nISBN: " + bookISBN + "\nTitle: " + bookTitle + "\nAuthors:\n" + bookAuthors.toString()
				+ "\nPrice: $" + bookPrice + "\n";
	}

}
