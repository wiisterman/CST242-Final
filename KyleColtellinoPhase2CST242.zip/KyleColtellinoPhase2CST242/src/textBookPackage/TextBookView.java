package textBookPackage;

import java.util.ArrayList;
import java.util.Arrays;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;



public class TextBookView extends Application {
	ArrayList<Author> author;
	MasterBookBag bookBag;
	private TextBook updatedBook;
	@Override
	public void start(Stage primaryStage) throws Exception {
		TextBookPane textBookPane = new TextBookPane();
		
		author = new ArrayList<Author>();
		bookBag = new MasterBookBag();
		bookBag.load();
		textBookPane.getInsertBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				String fn = textBookPane.getAuthorFirstNameField().getText();
				String ln = textBookPane.getAuthorLastNameField().getText();
				ArrayList<String> fnArray = new ArrayList<String>(Arrays.asList(fn.split(",")));
				ArrayList<String> lnArray = new ArrayList<String>(Arrays.asList(ln.split(",")));
				for (int i = 0; i < fnArray.size(); i++) {
					Author a = new Author(fnArray.get(i), lnArray.get(i));
					author.add(a);
				}

				TextBook s = new TextBook(textBookPane.getTextBookTitleField().getText(),
						textBookPane.getTextBookISBNField().getText(), author,
						Double.parseDouble(textBookPane.getTextBookPriceField().getText()));
				bookBag.add(s);
				textBookPane.getTextBookTitleField().clear();
				textBookPane.getTextBookISBNField().clear();
				textBookPane.getTextBookPriceField().clear();
				textBookPane.getAuthorFirstNameField().clear();
				textBookPane.getAuthorLastNameField().clear();
				textBookPane.getSearchField().clear();
				author = new ArrayList<>();
			}
		});
		
		textBookPane.getSearchBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String fnString = "";
				String lnString = "";

				if (!textBookPane.getSearchField().getText().equals("")) {
					TextBook searchedBook = bookBag.searchByBookISBN(textBookPane.getSearchField().getText());

					textBookPane.getTextBookTitleField().setText(searchedBook.getBookTitle());
					textBookPane.getTextBookISBNField().setText(searchedBook.getBookISBN());
					textBookPane.getTextBookPriceField().setText(String.valueOf(searchedBook.getBookPrice()));
					for (int i = 0; i < searchedBook.getBookAuthors().size(); i++) {
						fnString += searchedBook.getBookAuthors().get(i).getAuthorFirstName() + ",";
					}
					for (int j = 0; j < searchedBook.getBookAuthors().size(); j++) {
						lnString += searchedBook.getBookAuthors().get(j).getAuthorLastName() + ",";
					}
					textBookPane.getAuthorFirstNameField().setText(fnString);
					textBookPane.getAuthorLastNameField().setText(lnString);
					
				} else {

					textBookPane.getBookInfoArea().appendText("\nSEARCH FIELD IS EMPTY\n");

				}

			}

		});

		textBookPane.getRemoveBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				bookBag.removeByBookISBN(textBookPane.getSearchField().getText());
			}
		});
		
		textBookPane.getDisplayBooksBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				textBookPane.getBookInfoArea().setText(bookBag.display() + "\n");
			}
		});

		textBookPane.getClearBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				textBookPane.getBookInfoArea().clear();
				textBookPane.getTextBookTitleField().clear();
				textBookPane.getTextBookISBNField().clear();
				textBookPane.getTextBookPriceField().clear();
				textBookPane.getAuthorFirstNameField().clear();
				textBookPane.getAuthorLastNameField().clear();
				textBookPane.getSearchField().clear();
				textBookPane.getAuthorFirstNameField().clear();
				textBookPane.getAuthorLastNameField().clear();

			}
		});
		
		textBookPane.getUpdateBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				updatedBook = bookBag.searchByBookISBN(textBookPane.getSearchField().getText());

				String fn = textBookPane.getAuthorFirstNameField().getText();
				String ln = textBookPane.getAuthorLastNameField().getText();
				ArrayList<String> fnArray = new ArrayList<String>(Arrays.asList(fn.split(",")));
				ArrayList<String> lnArray = new ArrayList<String>(Arrays.asList(ln.split(",")));
				for (int i = 0; i < fnArray.size(); i++) {
					Author a = new Author(fnArray.get(i), lnArray.get(i));
					author.add(a);
				}
				updatedBook.setBookAuthors(author);
				updatedBook.setBookTitle(textBookPane.getTextBookTitleField().getText());
				updatedBook.setBookPrice(Double.parseDouble(textBookPane.getTextBookPriceField().getText()));
				bookBag.update(updatedBook);
			}
		});

		textBookPane.getSaveBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				bookBag.save();
			}
		});
		
		
		
		Scene scene = new Scene(textBookPane.getTextBookPane());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
